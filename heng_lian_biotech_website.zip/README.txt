HÉNG LIÁN Biotech Trading website starter

Files:
- index.html: complete responsive one-page website.

Before publishing:
1. Open index.html in a browser to preview.
2. The inquiry form is configured for henglianbiotech@gmail.com.
3. Review the product categories and all claims for accuracy and legal/platform compliance.
4. Publish using a host whose terms permit the final content. GitHub Pages is a free static hosting option for eligible public repositories, subject to its terms.
5. Add individual product listings only after confirming product-specific regulatory status and platform policies.

The inquiry form opens a prefilled email draft on the visitor's device; it does not store or transmit form data to a server.
